#!/bin/bash
set -e

# Debug: Check if the TOML file exists and its permissions
if [ ! -f /usr/local/bin/c2intbootconfig.toml ]; then
    echo "Error: /usr/local/bin/c2intbootconfig.toml not found."
    ls -l /usr/local/bin
    exit 1
fi

echo "Found /usr/local/bin/c2intbootconfig.toml with the following permissions:"
ls -l /usr/local/bin/c2intbootconfig.toml

# Parse the TOML file for database name, username, and server password using awk
DBNAME=$(awk -F ' = ' '/dbname/ {gsub(/[\"\"]/,"",$2); print $2}' /usr/local/bin/c2intbootconfig.toml)
USERNAME=$(awk -F ' = ' '/\[database\]/ {getline; getline; gsub(/[\"\"]/,"",$2); print $2}' /usr/local/bin/c2intbootconfig.toml)
PASSWORD=$(awk -F ' = ' '/\[c2App\]/{f=1} f && /password/ {gsub(/[\"\"]/,"",$2); print $2; f=0}' /usr/local/bin/c2intbootconfig.toml)
SCHEMA=$(awk -F ' = ' '/schema/ {gsub(/[\"\"]/,"",$2); print $2}' /usr/local/bin/c2intbootconfig.toml)

echo "Parsed database name: $DBNAME"
echo "Parsed username: $USERNAME"
echo "Parsed password: $PASSWORD"
echo "Parsed schema name: $SCHEMA"

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    CREATE ROLE $USERNAME WITH LOGIN ENCRYPTED PASSWORD '$PASSWORD';
    ALTER ROLE $USERNAME WITH SUPERUSER CREATEDB CREATEROLE REPLICATION BYPASSRLS;
    CREATE DATABASE $DBNAME WITH OWNER $USERNAME;
    
    \c $DBNAME
    
    -- Create the schema
    CREATE SCHEMA chirpstack;

    -- Grant connect privilege on the database to the user
    GRANT CONNECT ON DATABASE $DBNAME TO $USERNAME;

    -- Grant usage on the schema to the user
    GRANT USAGE ON SCHEMA chirpstack TO $USERNAME;

    -- Grant select, insert, update, and delete privileges on all tables in the schema to the user
    GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA chirpstack TO $USERNAME;

    -- Grant all privileges on all tables in the schema to the user
    GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA chirpstack TO $USERNAME;

    -- Grant all privileges on all sequences in the schema to the user
    GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA chirpstack TO $USERNAME;

    -- Grant all privileges on the database to the user
    GRANT ALL PRIVILEGES ON DATABASE $DBNAME TO $USERNAME;

    -- Grant all privileges on the schema to the user
    GRANT ALL ON SCHEMA chirpstack TO $USERNAME;
EOSQL

